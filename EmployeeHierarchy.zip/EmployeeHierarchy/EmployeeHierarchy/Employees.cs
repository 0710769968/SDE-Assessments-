﻿using EmployeeHierarchy.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeHierarchy
{
    public class Employees
    {

        // initialising List of Employeees
        List<Employee> all_employees = new List<Employee>();

        //initialising error  Class  
        MyCustomError custom_error = new MyCustomError();

        //Employees Constructor   
        public Employees(string EmployeeData)
        {
            //acccepting input from CSV

            using (StringReader myreader = new StringReader(EmployeeData))
            {

                string line;
                while ((line = myreader.ReadLine()) != null)
                {
                    Employee newEmployee = new Employee();
                    string[] EmployeeInfo = line.Split(',');
                    //column index
                    newEmployee.EmployeeId = EmployeeInfo[0];
                    newEmployee.EmployeeManager = EmployeeInfo[1];

                    try
                    {
                        newEmployee.EmployeeSalary = int.Parse(EmployeeInfo[2]);
                    }
                    catch
                    {
                        custom_error.Error = true;
                        custom_error.ErrorMessage = "......Hey, Salary MUST be an integer!.....";

                        throw new ArgumentException(".....Hey, Salary MUST be an integer!......");
                    }



                    if (string.IsNullOrEmpty(newEmployee.EmployeeManager))
                    {
                        newEmployee.EmployeeType = "CEO";
                    }

                    all_employees.Add(newEmployee);

                }
            }
            if (!EmployeeValidation.EmployeeIsEployeeAndManager(all_employees))
            {
                custom_error.Error = true;
                custom_error.ErrorMessage = "......Manager MUST be in  list of Employeees!.....";

                throw new ArgumentException("......Manager MUST be in  list of Employeees!....");
            }
            if (EmployeeValidation.CheckIfEmployeeISCEO(all_employees))
            {
                custom_error.Error = true;
                custom_error.ErrorMessage = ".....List of Employee Must Have ONY one CEO!.....";

                throw new ArgumentException(".....List of Employee Must Have ONY one CEO!.....");

            }

            if (EmployeeValidation.EmployeeCheckPerIndividualManager(all_employees))
            {

                custom_error.Error = true;
                custom_error.ErrorMessage = "....Employee MUST report to ONLY one Manager!.....";

                throw new ArgumentException("....Employee MUST report to ONLY one Manage!.....");

            }





        }

        public long GetBudgetForManager(string ManagerID)
        {
            long budget = 0;
            budget = EmployeeValidation.getBudgetForManager(ManagerID);
            return budget;
        }


    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeHierarchy.Models
{
    public class Employee
    {
        public string EmployeeId { get; set; }
        public string EmployeeManager { get; set; }
        //public string EmployeeName { get; set; }
        public int EmployeeSalary { get; set; }
        public string EmployeeType { get; set; }

    }
}

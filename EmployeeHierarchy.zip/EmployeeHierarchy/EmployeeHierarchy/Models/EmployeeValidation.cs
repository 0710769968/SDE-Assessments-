﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeHierarchy.Models
{
   
        public static class EmployeeValidation
        {

            public static bool EmployeeCheckPerIndividualManager(List<Employee> list_of_employees)
            {
                try
                {



                    // var Distint_Hashlist=list_of_employees.GroupBy(x => x.EmployeeId).Select(y => y.First());
                    // var Distint_Hashlist = list_of_employees.Select(x => new Employee { EmployeeId = x.EmployeeId, EmployeeType = x.EmployeeType }).Distinct().ToList();
                    var Distint_Hashlist = new HashSet<string>();
                    List<String> distintlist_of_employees = new List<String>();
                    bool Employee_MultibleReporting = false;

                    foreach (var employ in list_of_employees)
                    {
                        distintlist_of_employees.Add(employ.EmployeeId.ToString());
                    }

                    foreach (var employeename in distintlist_of_employees)
                    {
                        if (!Distint_Hashlist.Add(employeename))
                        {

                            Employee_MultibleReporting = true;

                        }
                    }

                    return Employee_MultibleReporting;
                }
                catch (Exception ex)
                {

                    return false;

                }
            }
            public static bool CheckIfEmployeeISCEO(List<Employee> list_of_employees)
            {

                bool Morethan1_CEO = false;

                int CEO_COUNT = 0;

                foreach (var employ in list_of_employees)
                {
                    if (employ.EmployeeType == "CEO")
                        CEO_COUNT += 1;
                }

                if (CEO_COUNT > 1)
                    Morethan1_CEO = true;

                return Morethan1_CEO;
            }

            public static bool CircularReferenceCheck(List<Employee> list_of_employees)
            {


                List<String> list_of_managers = new List<String>();

                bool circularRef = false;
                foreach (var employ in list_of_employees)
                {
                    list_of_managers.Add(employ.EmployeeManager);
                }

                foreach (var manager in list_of_managers)
                {
                    circularRef = checkEmployeeJunior(manager, list_of_employees);
                }

                return circularRef;
            }

            public static long getBudgetForManager(string ManagerId)
            {

                long Total_Salary = 0;
                long employeesalary = 0;
                List<string> employeejuniors = new List<string>();
                List<Employee> list_of_employees = new List<Employee>();



                foreach (var emplojunior in employeejuniors)
                {


                    foreach (var emp in list_of_employees)
                    {
                        if (emp.EmployeeManager == emplojunior)
                        {
                            employeesalary = getEmployee_Salary(emp.EmployeeId, list_of_employees);
                            Total_Salary += employeesalary;
                        }
                    }
                }
                foreach (var employ in list_of_employees)
                {
                    if (employ.EmployeeManager == ManagerId)
                    {
                        employeejuniors.Add(employ.EmployeeId);
                        ManagerId += employ.EmployeeSalary;
                    }

                }


                long Manager_Salary = getManager_Salary(ManagerId, list_of_employees);
                Total_Salary = Total_Salary + Manager_Salary;

                return Total_Salary;
            }

            public static bool EmployeeIsEployeeAndManager(List<Employee> list_of_employees)
            {


                List<String> list_of_managers = new List<String>();
                List<String> distintlist_of_employees = new List<String>();

                bool IsManagerEmployee = true;

                foreach (var employ in list_of_employees)
                {
                    list_of_managers.Add(employ.EmployeeManager);
                }


                foreach (var employ in list_of_employees)
                {
                    distintlist_of_employees.Add(employ.EmployeeId);
                }


                foreach (var manager in list_of_managers)
                {



                    if (!string.IsNullOrEmpty(manager))
                    {
                        if (!distintlist_of_employees.Contains(manager))
                            IsManagerEmployee = false;
                    }
                }

                return IsManagerEmployee;
            }


            private static long getManager_Salary(string managerId, List<Employee> list_of_employees)
            {
                long Manager_Salary = 0;

                foreach (var emp in list_of_employees)
                {
                    if (emp.EmployeeId == managerId)
                        Manager_Salary = emp.EmployeeSalary;
                }

                return Manager_Salary;
            }


            private static bool checkEmployeeJunior(string managerId, List<Employee> list_of_employees)
            {


                List<string> juniorstaff_LIst = new List<string>();
                bool employeeReportsTo_junior = false;

                foreach (var employ in list_of_employees)
                {
                    if (employ.EmployeeManager == managerId)
                    {
                        juniorstaff_LIst.Add(employ.EmployeeId);
                    }

                }

                if (juniorstaff_LIst.Contains(managerId))
                {
                    employeeReportsTo_junior = true;
                }


                return employeeReportsTo_junior;
            }

            private static long getEmployee_Salary(string employeeId, List<Employee> list_of_employees)
            {
                long Employee_Salary = 0;

                foreach (var employ in list_of_employees)
                {
                    if (employ.EmployeeId == employeeId)
                    {
                        Employee_Salary = employ.EmployeeSalary;

                    }

                }

                return Employee_Salary;
            }

        }
    }

